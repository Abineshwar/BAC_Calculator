package com.example.rabin.homework1;

        import android.support.v7.app.AppCompatActivity;
        import android.os.Bundle;
        import android.util.Log;
        import android.view.View;
        import android.widget.Button;
        import android.widget.CompoundButton;
        import android.widget.EditText;
        import android.widget.ProgressBar;
        import android.widget.RadioButton;
        import android.widget.SeekBar;
        import android.widget.Switch;
        import android.widget.TextView;
        import android.widget.Toast;
        import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final EditText weight = (EditText) findViewById(R.id.et_weight);
        //ToggleButton tbutton1 = (ToggleButton) findViewById(R.id.toggleButton);
        final Switch tsw = (Switch) findViewById(R.id.tswitch1);
        Button save = (Button) findViewById(R.id.b_save);
        Button adddrink = (Button) findViewById(R.id.b_adddrink);
        Button reset = (Button) findViewById(R.id.b_reset);
        //Button radiobg = (Button) findViewById(R.id.radioButtong);
        RadioButton radiob1 = (RadioButton) findViewById(R.id.radioButton1);
        RadioButton radiob2 = (RadioButton) findViewById(R.id.radioButton2);
        RadioButton radiob3 = (RadioButton) findViewById(R.id.radioButton3);
        SeekBar seek_bar1 = (SeekBar) findViewById(R.id.seekbar1);
        TextView tvw = (TextView) findViewById(R.id.tv_weight1);
        TextView tvds = (TextView) findViewById(R.id.tv_drinksize);
        //TextView tvgender = (TextView) findViewById(R.id.tv_gender);
        TextView tvap = (TextView) findViewById(R.id.tv_alcoholpercent);
        TextView tvresult = (TextView) findViewById(R.id.tv_result);
        TextView bac = (TextView) findViewById(R.id.tv_bac);
        TextView avalue = (TextView) findViewById(R.id.tv_value);
        ProgressBar pgbar = (ProgressBar) findViewById(R.id.pb);

        //seek_bar1.setMin(0);
        //seek_bar1.setMax(25);
        //seek_bar1.setProgress(5);
        //avalue.

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(weight.getText().toString().isEmpty() || Integer.parseInt(weight.getText().toString()) < 1 )
                {
                    weight.setError("Enter the weight in lb");
                }

            }
        });

        seek_bar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            int progressChangedValue = 0;

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int progressChangedValue = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

                Toast.makeText(MainActivity.this, "Seek bar progress is :" + progressChangedValue,
                        Toast.LENGTH_SHORT).show();

            }

        });

        tsw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    tsw.setText("Female");
                }
                else {
                    tsw.setText("Male");
                }


    }
});
           /*BAC Calculation
            ???A = ounces * alcohol percentage
            if (tsw.isChecked() = true)
            {
                bac = (A*6.24 / weight*0.55);
            }
            else {
                bac = (A * 6.24 / weight * 0.68);
            } */


    }
}